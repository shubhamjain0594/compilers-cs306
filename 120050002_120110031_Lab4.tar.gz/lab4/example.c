int a(int b){
	return 0;
}

int main(){
	float a=3.4;
	a++;
	printf("%f\n",a);
	return 0;
}